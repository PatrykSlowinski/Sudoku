package com.sudoku;

public class Main2 {
    public static final String ANSI_RED = "\u001B[31m";
    public static void main(String[] args) {
        System.out.println(ANSI_RED+"SDFSDFSDF");
    }
}
