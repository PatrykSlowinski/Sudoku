package view;

public interface GameView {
    public void showMessage(String m);

}
