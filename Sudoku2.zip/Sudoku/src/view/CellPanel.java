package view;

import model.CellState;
import model.SudokuGrid;

import javax.swing.*;
import java.awt.*;

public class CellPanel extends JPanel {
    private static final Color CELL_COLOR = Color.WHITE;
    private static final Color FIXED_CELL_COLOR = Color.BLUE;
    private static final Color VALID_CELL_COLOR = Color.BLACK;
    private static final Color INVALID_CELL_COLOR = Color.RED;
    private static final int CELL_SIZE = 60;
    private static final int TEXT_SIZE = 30;
    private BlockPanel blockPanel;
    private JTextField cellValue;
    private SudokuGrid sudokuGrid;
    private String value;
    private int row;
    private int column;

    public CellPanel(SudokuGrid sudokuGrid, int r, int c, BlockPanel bp) {
        this.sudokuGrid = sudokuGrid;
        this.row = r;
        this.column = c;
        this.blockPanel = bp;
        Dimension preferredSize = new Dimension(60,60);
        this.setBackground(CELL_COLOR);
        FlowLayout flowLayout = new FlowLayout();
        flowLayout.setHgap(0);
        flowLayout.setVgap(0);
        this.setLayout(flowLayout);
        if(this.sudokuGrid.cellState(this.row, this.column) == CellState.EMPTY){
            this.value = "";
        }
        else{
            this.value = Integer.toString(this.sudokuGrid.getValueAt(row,column));
        }

        this.cellValue = new JTextField();
        this.cellValue.setBackground(CELL_COLOR);
        if(this.sudokuGrid.cellState(this.row, this.column) == CellState.FIXED){
            this.cellValue.setForeground(FIXED_CELL_COLOR);
        }
        else{
            this.cellValue.setForeground(VALID_CELL_COLOR);
        }
        this.cellValue.setHorizontalAlignment(0);
        this.cellValue.setPreferredSize(preferredSize);
        this.cellValue.setFont(new Font("Serif", 0 ,30));
        this.cellValue.setText(this.value);
        this.add(this.cellValue);
        this.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        //this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        this.cellValue.setEditable(false);


    }
}
