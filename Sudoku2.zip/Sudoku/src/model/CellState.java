package model;

public enum CellState {
    FIXED,
    EMPTY,
    FILLED;
}
