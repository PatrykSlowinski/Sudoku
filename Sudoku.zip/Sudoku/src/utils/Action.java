package utils;

public enum Action {
    FILLCELL,
    EMPTYCELL;
}
