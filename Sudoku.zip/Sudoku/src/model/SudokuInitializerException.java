package model;

public class SudokuInitializerException extends Exception{
    public SudokuInitializerException() {
    }
    public SudokuInitializerException(String msg) {
        super(msg);
    }
}
